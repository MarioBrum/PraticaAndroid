package com.example.pratica1_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private TextView mensagem;
    private EditText X;
    private EditText Y;
    private EditText Z;
    private SensorManager sensorManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        X = (EditText)findViewById(R.id.editTextX);
        Y = (EditText)findViewById(R.id.editTextY);
        Z = (EditText)findViewById(R.id.editTextZ);

        sensorManager = (SensorManager)
                getSystemService(Context.SENSOR_SERVICE);
        Sensor sensorAccelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if(sensorAccelerometer != null)
        {
            sensorManager.registerListener(MainActivity.this, sensorAccelerometer,
                    SensorManager.SENSOR_DELAY_NORMAL);
        }else
        {
            //lightValue.setText("Light sensor not supported");
        }
    }


    @Override
    public void onSensorChanged(SensorEvent event) {
        Sensor sensor = event.sensor;
        if(sensor.getType() == Sensor.TYPE_ACCELEROMETER){
            X.setText("X: "+ event.values[0]);
            Y.setText("Y: "+ event.values[1]);
            Z.setText("Z: "+ event.values[2]);
        }
        if(event.values[0] > 15.0 || event.values[1] > 15.0 || event.values[2] > 15.0 ){
            setContentView(R.layout.activity_second);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}