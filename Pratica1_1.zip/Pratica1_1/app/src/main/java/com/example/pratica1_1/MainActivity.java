package com.example.pratica1_1;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private EditText numero1;
    private EditText numero2;
    private TextView resultado;
    private Button botao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        botao = (Button) findViewById(R.id.botao);
        numero1 = (EditText) findViewById(R.id.editText1);
        numero2 = (EditText) findViewById(R.id.editText2);
        resultado = (TextView) findViewById(R.id.resultado);
        onAdd();
    }

    private void onAdd() {
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int valor = Integer.parseInt(numero1.getText().toString()) +
                        Integer.parseInt(numero2.getText().toString());
                resultado.setText("Resultado: " + Integer.toString(valor));
            }
        });
    }

}