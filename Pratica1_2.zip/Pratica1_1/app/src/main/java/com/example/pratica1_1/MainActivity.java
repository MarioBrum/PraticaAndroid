package com.example.pratica1_1;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    private EditText mensagemRecebida;
    private TextView mensagemExibida;
    String conteudo;
    private Button botao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        botao = (Button) findViewById(R.id.botao);
        mensagemRecebida = (EditText) findViewById(R.id.editText1);

        onAdd();
    }

    private void onAdd() {
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                conteudo = mensagemRecebida.getText().toString();
                setContentView(R.layout.activity_second);
                mensagemExibida = (TextView) findViewById(R.id.mensagem);
                mensagemExibida.setText(conteudo);
            }
        });
    }

}