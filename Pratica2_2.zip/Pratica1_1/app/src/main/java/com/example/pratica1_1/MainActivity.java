package com.example.pratica1_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor light;
    TextView lightValue;
    TextView accelerometerValue;
    TextView temperatureValue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lightValue = (TextView)findViewById(R.id.textView1);
        accelerometerValue = (TextView)findViewById(R.id.textView2);
        temperatureValue = (TextView)findViewById(R.id.textView3);


        sensorManager = (SensorManager)
                getSystemService(Context.SENSOR_SERVICE);
        Sensor sensorLight = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        Sensor sensorAccelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        Sensor sensorTemperature = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);
        if(sensorLight != null)
        {
            sensorManager.registerListener(MainActivity.this, sensorLight,
                    SensorManager.SENSOR_DELAY_NORMAL);
        }else
        {
            lightValue.setText("Light sensor not supported");
        }
        if(sensorAccelerometer != null)
        {
            sensorManager.registerListener(MainActivity.this, sensorAccelerometer,
                    SensorManager.SENSOR_DELAY_NORMAL);
        }else
        {
            accelerometerValue.setText("Accelerometer not supported");
        }
        if(sensorTemperature != null)
        {
            sensorManager.registerListener(MainActivity.this, sensorTemperature,
                    SensorManager.SENSOR_DELAY_NORMAL);
        }else
        {
            temperatureValue.setText("Temperature not supported");
        }
    }


    @Override
    public void onSensorChanged(SensorEvent event) {
        Sensor sensor = event.sensor;
        if(sensor.getType() == Sensor.TYPE_LIGHT)
        {
            lightValue.setText("Light Intensity: " + event.values[0]);
        }
        if(sensor.getType() == Sensor.TYPE_ACCELEROMETER)
        {
            accelerometerValue.setText("X: " + event.values[0] +
                    "Y: " + event.values[1]+
                    "Z: " + event.values[2]);
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}